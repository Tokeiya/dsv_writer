CREATE VIEW basic_view (id, lhs_path, rhs_path, unigram_similarity, bigram_similarity, trigram_similarity) AS
WITH tmp_l AS (SELECT s.id,
                      f_1.path AS lhs_path,
                      s.rhs_id,
                      s.unigram_similarity,
                      s.bigram_similarity,
                      s.trigram_similarity
               FROM file_data f_1
	                    RIGHT JOIN similarity_data s ON f_1.id = s.lhs_id)
SELECT t.id,
       t.lhs_path,
       f.path AS rhs_path,
       t.unigram_similarity,
       t.bigram_similarity,
       t.trigram_similarity
FROM tmp_l t
	     LEFT JOIN file_data f ON t.rhs_id = f.id;

ALTER TABLE basic_view
	OWNER TO tokeiya3;

